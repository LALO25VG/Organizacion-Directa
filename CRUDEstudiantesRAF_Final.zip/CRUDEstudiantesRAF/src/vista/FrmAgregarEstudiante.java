package vista;

import controlador.ControladorCRUDEstudiantes;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

/**
 * Clase FrmAgregarEstudiante representa el formulario de interfaz gráfica para
 * agregar un nuevo estudiante al sistema.
 */
public class FrmAgregarEstudiante extends javax.swing.JFrame {

    private final ControladorCRUDEstudiantes objControladorCRUDEst;

    /**
     * Constructor del formulario.
     *
     * @param objCtrlCRUDEst Controlador del CRUD de estudiantes
     */
    public FrmAgregarEstudiante(ControladorCRUDEstudiantes objCtrlCRUDEst) {
        initComponents();
        this.objControladorCRUDEst = objCtrlCRUDEst;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        gpoBotonesGrupo = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNumControl = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        cboCarrera = new javax.swing.JComboBox<>();
        rdbtnGrupoA = new javax.swing.JRadioButton();
        rdbtnGrupoB = new javax.swing.JRadioButton();
        rdbtnGrupoC = new javax.swing.JRadioButton();
        cboSemestre = new javax.swing.JComboBox<>();
        txtApellidos = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Agregar Estudiante");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(0, 153, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 0));
        jLabel2.setText("Tecnologico del Valle de Oaxaca");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 204, 0));
        jLabel9.setText("Registrar Estudiantes");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Identificacion de x32.png"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, -1, -1));

        txtNumControl.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNumControl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumControlActionPerformed(evt);
            }
        });
        txtNumControl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNumControlKeyPressed(evt);
            }
        });
        jPanel1.add(txtNumControl, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 200, -1));

        txtNombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNombreKeyPressed(evt);
            }
        });
        jPanel1.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 160, 200, -1));

        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Guardar 48x48.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        btnGuardar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnGuardarKeyPressed(evt);
            }
        });
        jPanel1.add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 360, -1, -1));

        cboCarrera.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ing. Informática", "Ing. en TIC", "Ing. en Ciencia de Datos", "Ing. en Gestión Empresarial", "Ing. Forestal", "Ing. en Agronomía", "Lic. en Biología" }));
        cboCarrera.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cboCarreraKeyPressed(evt);
            }
        });
        jPanel1.add(cboCarrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 320, 200, -1));

        gpoBotonesGrupo.add(rdbtnGrupoA);
        rdbtnGrupoA.setSelected(true);
        rdbtnGrupoA.setText("A");
        rdbtnGrupoA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rdbtnGrupoAKeyPressed(evt);
            }
        });
        jPanel1.add(rdbtnGrupoA, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 280, -1, -1));

        gpoBotonesGrupo.add(rdbtnGrupoB);
        rdbtnGrupoB.setText("B");
        rdbtnGrupoB.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rdbtnGrupoBKeyPressed(evt);
            }
        });
        jPanel1.add(rdbtnGrupoB, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 280, -1, -1));

        gpoBotonesGrupo.add(rdbtnGrupoC);
        rdbtnGrupoC.setText("C");
        rdbtnGrupoC.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rdbtnGrupoCKeyPressed(evt);
            }
        });
        jPanel1.add(rdbtnGrupoC, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 280, -1, -1));

        cboSemestre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13" }));
        cboSemestre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cboSemestreKeyPressed(evt);
            }
        });
        jPanel1.add(cboSemestre, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 240, 100, -1));

        txtApellidos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtApellidos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtApellidosKeyPressed(evt);
            }
        });
        jPanel1.add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 200, -1));

        jLabel10.setText("Numero de Control");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, -1, -1));

        jLabel5.setText("Nombre");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, -1, -1));

        jLabel6.setText("Apellidos");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, -1, -1));

        jLabel7.setText("Semestre");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, -1, -1));

        jLabel8.setText("Grupo");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 280, -1, -1));

        jLabel1.setText("Carrera");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 320, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8_customer_32px_1.png"))); // NOI18N
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8_customer_32px_1.png"))); // NOI18N
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, -1, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8_customer_32px_1.png"))); // NOI18N
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 510, 440));

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void txtNumControlKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumControlKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.txtNombre.requestFocus();
    }//GEN-LAST:event_txtNumControlKeyPressed

    private void txtNombreKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.txtApellidos.requestFocus();
    }//GEN-LAST:event_txtNombreKeyPressed

    private void txtApellidosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidosKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.cboSemestre.requestFocus();
    }//GEN-LAST:event_txtApellidosKeyPressed

    private void cboSemestreKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cboSemestreKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.rdbtnGrupoA.requestFocus();
    }//GEN-LAST:event_cboSemestreKeyPressed

    private void rdbtnGrupoAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rdbtnGrupoAKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.cboCarrera.requestFocus();
    }//GEN-LAST:event_rdbtnGrupoAKeyPressed

    private void rdbtnGrupoBKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rdbtnGrupoBKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.cboCarrera.requestFocus();
    }//GEN-LAST:event_rdbtnGrupoBKeyPressed

    private void rdbtnGrupoCKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rdbtnGrupoCKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.cboCarrera.requestFocus();
    }//GEN-LAST:event_rdbtnGrupoCKeyPressed

    private void cboCarreraKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cboCarreraKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.btnGuardar.requestFocus();
    }//GEN-LAST:event_cboCarreraKeyPressed

    private void btnGuardarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnGuardarKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            guardarDatos();
        }
    }//GEN-LAST:event_btnGuardarKeyPressed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        guardarDatos();
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void txtNumControlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumControlActionPerformed
    }//GEN-LAST:event_txtNumControlActionPerformed

    /**
     * Guarda los datos del estudiante usando el controlador y muestra mensajes
     * según el resultado.
     */
    private void guardarDatos() {
        String numControl = this.txtNumControl.getText();
        String nombre = this.txtNombre.getText();
        String ape = this.txtApellidos.getText();
        int semestre = Integer.parseInt(this.cboSemestre.getSelectedItem().toString());
        char grupo = this.rdbtnGrupoA.isSelected() ? 'A' : this.rdbtnGrupoB.isSelected() ? 'B' : 'C';
        String carrera = this.cboCarrera.getSelectedItem().toString();

        if (!this.objControladorCRUDEst.validaNumControl(numControl)) {
            JOptionPane.showMessageDialog(this, "Numero de control invalido");
            return;
        }

        boolean guardado = this.objControladorCRUDEst.guardarRegistro(numControl, nombre, ape, semestre, grupo, carrera);

        if (guardado) {
            JOptionPane.showMessageDialog(this, "Registro guardado con exito");
            objControladorCRUDEst.llenarTabla();
            limpiarFormulario();
        } else {
            JOptionPane.showMessageDialog(this, "El numero de control ya existe");
        }
    }

    /**
     * Limpia los campos del formulario para un nuevo registro.
     */
    private void limpiarFormulario() {
        this.txtNumControl.setText("");
        this.txtNombre.setText("");
        this.txtApellidos.setText("");
        this.cboSemestre.setSelectedIndex(0);
        this.rdbtnGrupoA.setSelected(true);
        this.cboCarrera.setSelectedItem("Ing. Informática");
        this.txtNumControl.requestFocus();
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardar;
    private javax.swing.JComboBox<String> cboCarrera;
    private javax.swing.JComboBox<String> cboSemestre;
    private javax.swing.ButtonGroup gpoBotonesGrupo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton rdbtnGrupoA;
    private javax.swing.JRadioButton rdbtnGrupoB;
    private javax.swing.JRadioButton rdbtnGrupoC;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNumControl;
    // End of variables declaration//GEN-END:variables
}
