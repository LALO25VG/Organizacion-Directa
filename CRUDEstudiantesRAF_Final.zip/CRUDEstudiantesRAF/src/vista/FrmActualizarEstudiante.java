package vista;

import controlador.ControladorCRUDEstudiantes;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

/**
 * Panel para actualizar la información de un estudiante. Permite buscar por
 * número de control, modificar los datos y guardar los cambios.
 */
public class FrmActualizarEstudiante extends javax.swing.JFrame {

    private ControladorCRUDEstudiantes objControladorCRUDEst;

    /**
     * Constructor que inicializa el formulario y desactiva los campos de
     * edición.
     *
     * @param objCtrlCRUDEst instancia del controlador que maneja la lógica de
     * negocio.
     */
    public FrmActualizarEstudiante(ControladorCRUDEstudiantes objCtrlCRUDEst) {
        initComponents();
        this.objControladorCRUDEst = objCtrlCRUDEst;
        this.deshabilitaComponentes(false);
    }

    /**
     * Habilita o deshabilita los campos del formulario según el valor
     * proporcionado.
     *
     * @param valor true para habilitar los campos, false para deshabilitarlos.
     */
    private void deshabilitaComponentes(boolean valor) {
        this.txtNombre.setEnabled(valor);
        this.txtApellidos.setEnabled(valor);
        this.cboSemestre.setEnabled(valor);
        this.rdbtnGrupoA.setEnabled(valor);
        this.rdbtnGrupoB.setEnabled(valor);
        this.rdbtnGrupoC.setEnabled(valor);
        this.cboCarrera.setEnabled(valor);
        this.btnActualizar.setEnabled(valor);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        GruposABC = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtNumControl = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        cboSemestre = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        rdbtnGrupoA = new javax.swing.JRadioButton();
        rdbtnGrupoC = new javax.swing.JRadioButton();
        rdbtnGrupoB = new javax.swing.JRadioButton();
        jLabel8 = new javax.swing.JLabel();
        cboCarrera = new javax.swing.JComboBox<>();
        btnActualizar = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnBuscarEstudiante = new javax.swing.JButton();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8_customer_32px_1.png"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, -1));

        jLabel1.setText("Carrera");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 370, -1, -1));

        jLabel5.setText("Nombre");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 180, -1, -1));

        jLabel6.setText("Apellidos");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 230, -1, -1));

        txtNumControl.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNumControl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txtNumControl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNumControlKeyPressed(evt);
            }
        });
        jPanel1.add(txtNumControl, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 130, 130, 20));

        txtNombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNombreKeyPressed(evt);
            }
        });
        jPanel1.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 180, 130, 20));

        txtApellidos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtApellidos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txtApellidos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtApellidosKeyPressed(evt);
            }
        });
        jPanel1.add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 230, 130, 20));

        cboSemestre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13" }));
        cboSemestre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        cboSemestre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cboSemestreKeyPressed(evt);
            }
        });
        jPanel1.add(cboSemestre, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 270, -1, -1));

        jLabel7.setText("Semestre");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 280, -1, -1));

        GruposABC.add(rdbtnGrupoA);
        rdbtnGrupoA.setSelected(true);
        rdbtnGrupoA.setText("A");
        rdbtnGrupoA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rdbtnGrupoAKeyPressed(evt);
            }
        });
        jPanel1.add(rdbtnGrupoA, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 320, -1, -1));

        GruposABC.add(rdbtnGrupoC);
        rdbtnGrupoC.setText("C");
        rdbtnGrupoC.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rdbtnGrupoCKeyPressed(evt);
            }
        });
        jPanel1.add(rdbtnGrupoC, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 320, -1, -1));

        GruposABC.add(rdbtnGrupoB);
        rdbtnGrupoB.setText("B");
        rdbtnGrupoB.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rdbtnGrupoBKeyPressed(evt);
            }
        });
        jPanel1.add(rdbtnGrupoB, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 320, -1, -1));

        jLabel8.setText("Grupo");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 320, -1, -1));

        cboCarrera.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ing. Informática", "Ing. en TIC", "Ing. en Ciencia de Datos", "Ing. en Gestión Empresarial", "Ing. Forestal", "Ing. en Agronomía", "Lic. en Biología" }));
        cboCarrera.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        cboCarrera.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cboCarreraKeyPressed(evt);
            }
        });
        jPanel1.add(cboCarrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 370, 140, 20));

        btnActualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Cambiar 48x48.png"))); // NOI18N
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });
        btnActualizar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnActualizarKeyPressed(evt);
            }
        });
        jPanel1.add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 340, -1, -1));

        jLabel9.setText("Numero de Control");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 204, 255));
        jLabel4.setText("Actualizar Datos del Estudiante");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8_customer_32px_1.png"))); // NOI18N
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8_customer_32px_1.png"))); // NOI18N
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));

        jLabel2.setBackground(new java.awt.Color(0, 153, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 0));
        jLabel2.setText("Tecnologico del Valle de Oaxaca");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, -1, -1));

        btnBuscarEstudiante.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/BusquedaPersona 48x48.png"))); // NOI18N
        btnBuscarEstudiante.setText("Buscar");
        btnBuscarEstudiante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarEstudianteActionPerformed(evt);
            }
        });
        btnBuscarEstudiante.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnBuscarEstudianteKeyPressed(evt);
            }
        });
        jPanel1.add(btnBuscarEstudiante, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 130, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 6, 516, 458));
    }// </editor-fold>//GEN-END:initComponents

    private void txtNumControlKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumControlKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.buscar();
    }//GEN-LAST:event_txtNumControlKeyPressed

    private void txtNombreKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            this.txtApellidos.requestFocus();
        }
    }//GEN-LAST:event_txtNombreKeyPressed

    private void cboSemestreKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cboSemestreKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            this.rdbtnGrupoA.requestFocus();
        }
    }//GEN-LAST:event_cboSemestreKeyPressed

    private void txtApellidosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidosKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            this.cboSemestre.requestFocus();
        }
    }//GEN-LAST:event_txtApellidosKeyPressed

    private void rdbtnGrupoAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rdbtnGrupoAKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            this.cboCarrera.requestFocus();
        }
    }//GEN-LAST:event_rdbtnGrupoAKeyPressed

    private void rdbtnGrupoBKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rdbtnGrupoBKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            this.cboCarrera.requestFocus();
        }
    }//GEN-LAST:event_rdbtnGrupoBKeyPressed

    private void rdbtnGrupoCKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rdbtnGrupoCKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            this.cboCarrera.requestFocus();
        }
    }//GEN-LAST:event_rdbtnGrupoCKeyPressed

    private void btnActualizarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnActualizarKeyPressed
        actualizarRegistro();

    }//GEN-LAST:event_btnActualizarKeyPressed

    private void btnBuscarEstudianteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarEstudianteActionPerformed
        this.buscar();
    }//GEN-LAST:event_btnBuscarEstudianteActionPerformed

    private void btnBuscarEstudianteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnBuscarEstudianteKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.buscar();
    }//GEN-LAST:event_btnBuscarEstudianteKeyPressed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        actualizarRegistro();
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void cboCarreraKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cboCarreraKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.btnActualizar.requestFocus();
    }//GEN-LAST:event_cboCarreraKeyPressed

    /**
     * Realiza la búsqueda del estudiante por número de control y carga sus
     * datos en el formulario.
     */
    private void buscar() {
        String numControl = this.txtNumControl.getText().trim();

        if (!objControladorCRUDEst.validaNumControl(numControl)) {
            JOptionPane.showMessageDialog(this, "Número de control inválido. Debe tener 8 caracteres.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String registro[] = this.objControladorCRUDEst.buscarRegistro(numControl);

        if (registro != null) {
            this.txtNombre.setText(registro[1]);
            this.txtApellidos.setText(registro[2]);

            try {
                int semestre = Integer.parseInt(registro[3].trim());
                this.cboSemestre.setSelectedItem(String.valueOf(semestre));
            } catch (NumberFormatException e) {
                System.err.println("Error al convertir semestre: " + registro[3]);
            }

            char grupo = registro[4].charAt(0);
            switch (grupo) {
                case 'A' ->
                    this.rdbtnGrupoA.setSelected(true);
                case 'B' ->
                    this.rdbtnGrupoB.setSelected(true);
                case 'C' ->
                    this.rdbtnGrupoC.setSelected(true);
            }

            this.cboCarrera.setSelectedItem(registro[5]);
            this.btnActualizar.setEnabled(true);
            this.deshabilitaComponentes(true);
        } else {
            JOptionPane.showMessageDialog(this, "El registro no existe", "Búsqueda", JOptionPane.WARNING_MESSAGE);
            limpiarFormulario();
        }
    }

    /**
     * Toma los datos del formulario y actualiza el registro correspondiente.
     */
    private void actualizarRegistro() {
        String nc = this.txtNumControl.getText().trim();
        String nombre = this.txtNombre.getText().trim();
        String apellidos = this.txtApellidos.getText().trim();
        int semestre = Integer.parseInt(this.cboSemestre.getSelectedItem().toString());
        String carrera = this.cboCarrera.getSelectedItem().toString();

        char grupo = 'A';
        if (this.rdbtnGrupoB.isSelected()) {
            grupo = 'B';
        } else if (this.rdbtnGrupoC.isSelected()) {
            grupo = 'C';
        }

        boolean modificado = objControladorCRUDEst.modificarRegistro(nc, nombre, apellidos, semestre, grupo, carrera);

        if (modificado) {
            JOptionPane.showMessageDialog(this, "Registro actualizado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            limpiarFormulario();
            deshabilitaComponentes(false);
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo actualizar el registro", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Limpia todos los campos del formulario.
     */
    private void limpiarFormulario() {
        this.txtNumControl.setText("");
        this.txtNombre.setText("");
        this.txtApellidos.setText("");
        this.cboSemestre.setSelectedIndex(0);
        this.rdbtnGrupoA.setSelected(true);
        this.cboCarrera.setSelectedItem("Ing. Informática");
        this.txtNumControl.requestFocus();
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup GruposABC;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnBuscarEstudiante;
    private javax.swing.JComboBox<String> cboCarrera;
    private javax.swing.JComboBox<String> cboSemestre;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton rdbtnGrupoA;
    private javax.swing.JRadioButton rdbtnGrupoB;
    private javax.swing.JRadioButton rdbtnGrupoC;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNumControl;
    // End of variables declaration//GEN-END:variables
}
