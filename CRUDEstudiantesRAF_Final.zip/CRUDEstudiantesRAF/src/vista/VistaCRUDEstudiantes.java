package vista;

import controlador.ControladorCRUDEstudiantes;
import modelo.ArchivoOrganizacionDirecta;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.KeyEvent;

/**
 * Clase que representa la ventana principal del sistema CRUD de estudiantes.
 * Permite agregar, eliminar, modificar y buscar estudiantes, mostrando los
 * registros en una tabla. Se comunica con un controlador y utiliza un archivo
 * de organización directa para persistencia.
 */
public class VistaCRUDEstudiantes extends javax.swing.JFrame {

    private final ControladorCRUDEstudiantes objControladorCRUDEst;
    private final ArchivoOrganizacionDirecta objArchivo;

    /**
     * Constructor que inicializa la interfaz gráfica y el controlador del CRUD.
     */
    public VistaCRUDEstudiantes() {
        initComponents();
        this.objArchivo = new ArchivoOrganizacionDirecta();
        this.objControladorCRUDEst = new ControladorCRUDEstudiantes(this, this.objArchivo);
        this.objControladorCRUDEst.llenarTabla();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNumControlBuscar = new javax.swing.JTextField();
        btnBuscarEstudiante = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtblEstudiantes = new javax.swing.JTable();
        btnModificar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Agenda Estudiantes");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(51, 255, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 28)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 204, 51));
        jLabel2.setText("Tecnologico del Valle de Oaxaca");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/LOGO TEC 128x128.jpeg"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        txtNumControlBuscar.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        txtNumControlBuscar.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNumControlBuscar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txtNumControlBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNumControlBuscarKeyPressed(evt);
            }
        });
        jPanel1.add(txtNumControlBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 150, 230, 40));

        btnBuscarEstudiante.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/BusquedaPersona 48x48.png"))); // NOI18N
        btnBuscarEstudiante.setText("Buscar");
        btnBuscarEstudiante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarEstudianteActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuscarEstudiante, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 140, -1, -1));

        btnAgregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/AgregarPersona 64x64.png"))); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAgregarMouseClicked(evt);
            }
        });
        jPanel1.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 440, 200, -1));

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/EliminarPersona 64x64.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminarMouseClicked(evt);
            }
        });
        jPanel1.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 440, 200, -1));

        jtblEstudiantes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Num. Control", "Nombre", "Apellidos", "Semestre", "Grupo", "Carrera"
            }
        ));
        jScrollPane1.setViewportView(jtblEstudiantes);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, 910, 200));

        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Cambiar 64x64.png"))); // NOI18N
        btnModificar.setText("Actualizar");
        btnModificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnModificarMouseClicked(evt);
            }
        });
        jPanel1.add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 440, 200, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 0));
        jLabel4.setText("Agenda de Estudiantes");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 60, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Agenda x32.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 60, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/LOGO ITVO 85x85.jpeg"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 10, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1039, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 570, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Abre la ventana de formulario para agregar un nuevo estudiante.
     *
     * @param evt evento de clic del mouse
     */

    private void btnAgregarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAgregarMouseClicked
        FrmAgregarEstudiante objAgregarEstudiante = new FrmAgregarEstudiante(this.objControladorCRUDEst);
        objAgregarEstudiante.setVisible(true);
        objAgregarEstudiante.setLocationRelativeTo(this);
    }//GEN-LAST:event_btnAgregarMouseClicked

    /**
     * Abre la ventana de formulario para eliminar un estudiante existente.
     *
     * @param evt evento de clic del mouse
     */

    private void btnEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseClicked
        FrmEliminarEstudiante objEliminarEstudiante = new FrmEliminarEstudiante(this.objControladorCRUDEst);
        objEliminarEstudiante.pack();
        objEliminarEstudiante.setLocationRelativeTo(null);
        objEliminarEstudiante.setVisible(true);
    }//GEN-LAST:event_btnEliminarMouseClicked

    /**
     * Abre la ventana de formulario para actualizar los datos de un estudiante.
     *
     * @param evt evento de clic del mouse
     */

    private void btnModificarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnModificarMouseClicked
        FrmActualizarEstudiante objActualizarEstudiante = new FrmActualizarEstudiante(this.objControladorCRUDEst);
        objActualizarEstudiante.pack();
        objActualizarEstudiante.setLocationRelativeTo(null);
        objActualizarEstudiante.setVisible(true);
    }//GEN-LAST:event_btnModificarMouseClicked

    /**
     * Evento de clic sobre el botón buscar.
     *
     * @param evt evento del botón
     */

    private void btnBuscarEstudianteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarEstudianteActionPerformed
        this.buscarRegistro();
    }//GEN-LAST:event_btnBuscarEstudianteActionPerformed

    /**
     * Permite ejecutar la búsqueda al presionar ENTER en el campo de búsqueda.
     *
     * @param evt evento de teclado
     */

    private void txtNumControlBuscarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumControlBuscarKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            buscarRegistro();
        }
    }//GEN-LAST:event_txtNumControlBuscarKeyPressed

    /**
     * Busca un número de control en la tabla, lo selecciona y lo resalta si es
     * encontrado. Si no lo encuentra, muestra un mensaje de advertencia.
     */
    private void buscarRegistro() {
        String numControl = txtNumControlBuscar.getText().trim();

        if (numControl.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingresa un número de control.",
                    "Campo vacío", JOptionPane.WARNING_MESSAGE);
            return;
        }

        DefaultTableModel modelo = (DefaultTableModel) jtblEstudiantes.getModel();
        boolean encontrado = false;

        for (int x = 0; x < modelo.getRowCount(); x++) {
            String ncTabla = modelo.getValueAt(x, 0).toString();
            if (ncTabla.equalsIgnoreCase(numControl)) {
                jtblEstudiantes.setRowSelectionInterval(x, x);
                jtblEstudiantes.scrollRectToVisible(jtblEstudiantes.getCellRect(x, 0, true));
                jtblEstudiantes.setSelectionBackground(Color.ORANGE);
                jtblEstudiantes.setSelectionForeground(Color.WHITE);
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(this,
                    "Registro no encontrado en la tabla.",
                    "Búsqueda",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * Método principal que inicia la aplicación.
     *
     * @param args argumentos de línea de comandos (no se usan)
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VistaCRUDEstudiantes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscarEstudiante;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable jtblEstudiantes;
    private javax.swing.JTextField txtNumControlBuscar;
    // End of variables declaration//GEN-END:variables
}
