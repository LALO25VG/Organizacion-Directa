package vista;

import controlador.ControladorCRUDEstudiantes;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

/**
 * Interfaz gráfica para eliminar un estudiante del sistema. Permite buscar un
 * estudiante por su número de control y eliminar su registro si existe.
 */
public class FrmEliminarEstudiante extends javax.swing.JFrame {

    ControladorCRUDEstudiantes objControladorCRUDEst;

    /**
     * Constructor que inicializa la interfaz y deshabilita los campos hasta que
     * se busque un estudiante válido.
     *
     * @param objCtrlCRUDEst Objeto controlador con la lógica de negocio del
     * CRUD.
     */
    public FrmEliminarEstudiante(ControladorCRUDEstudiantes objCtrlCRUDEst) {
        initComponents();
        this.objControladorCRUDEst = objCtrlCRUDEst;
        this.deshabilitaComponentes(false);
    }

    /**
     * Habilita o deshabilita los componentes de datos del estudiante.
     *
     * @param valor true para habilitar, false para deshabilitar.
     */
    private void deshabilitaComponentes(boolean valor) {
        this.txtNombre.setEnabled(valor);
        this.txtApellidos.setEnabled(valor);
        this.cboSemestre.setEnabled(valor);
        this.rdbtnGrupoA.setEnabled(valor);
        this.rdbtnGrupoB.setEnabled(valor);
        this.rdbtnGrupoC.setEnabled(valor);
        this.cboCarrera.setEnabled(valor);
        this.btnEliminar.setEnabled(valor);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        gpoBotonesGrupo = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtNumControl = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        cboSemestre = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        rdbtnGrupoA = new javax.swing.JRadioButton();
        rdbtnGrupoC = new javax.swing.JRadioButton();
        rdbtnGrupoB = new javax.swing.JRadioButton();
        jLabel8 = new javax.swing.JLabel();
        cboCarrera = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnBuscarEstudiante = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();

        setTitle("Eliminar Estudiantes");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 0, 51));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Borrar_Archivo_32.png"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, -1, -1));

        txtNumControl.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNumControl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txtNumControl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumControlActionPerformed(evt);
            }
        });
        txtNumControl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNumControlKeyPressed(evt);
            }
        });
        jPanel1.add(txtNumControl, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, 130, 20));

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/EliminarPersona 48x48.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        btnEliminar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnEliminarKeyPressed(evt);
            }
        });
        jPanel1.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 280, -1, -1));

        jLabel9.setText("Numero de Control");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8_customer_32px_1.png"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        jLabel1.setText("Carrera");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, -1, -1));

        jLabel5.setText("Nombre");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, -1, -1));

        jLabel6.setText("Apellidos");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, -1, -1));

        txtNombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, 130, 20));

        txtApellidos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtApellidos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 240, 130, 20));

        cboSemestre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13" }));
        cboSemestre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(cboSemestre, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 280, -1, -1));

        jLabel7.setText("Semestre");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, -1, -1));

        gpoBotonesGrupo.add(rdbtnGrupoA);
        rdbtnGrupoA.setSelected(true);
        rdbtnGrupoA.setText("A");
        jPanel1.add(rdbtnGrupoA, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 330, -1, -1));

        gpoBotonesGrupo.add(rdbtnGrupoC);
        rdbtnGrupoC.setText("C");
        jPanel1.add(rdbtnGrupoC, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 330, -1, -1));

        gpoBotonesGrupo.add(rdbtnGrupoB);
        rdbtnGrupoB.setText("B");
        jPanel1.add(rdbtnGrupoB, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 330, -1, -1));

        jLabel8.setText("Grupo");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, -1, -1));

        cboCarrera.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ing. Informática", "Ing. en TIC", "Ing. en Ciencia de Datos", "Ing. en Gestión Empresarial", "Ing. Forestal", "Ing. en Agronomía", "Lic. en Biología" }));
        cboCarrera.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(cboCarrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 380, 200, 20));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8_customer_32px_1.png"))); // NOI18N
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, -1, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8_customer_32px_1.png"))); // NOI18N
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        jLabel2.setBackground(new java.awt.Color(0, 153, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 0));
        jLabel2.setText("Tecnologico del Valle de Oaxaca");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, -1, -1));

        btnBuscarEstudiante.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/BusquedaPersona 48x48.png"))); // NOI18N
        btnBuscarEstudiante.setText("Buscar");
        btnBuscarEstudiante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarEstudianteActionPerformed(evt);
            }
        });
        btnBuscarEstudiante.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnBuscarEstudianteKeyPressed(evt);
            }
        });
        jPanel1.add(btnBuscarEstudiante, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 140, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 0, 51));
        jLabel11.setText("Eliminar Estudiantes");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 502, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 466, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        this.eliminar();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnBuscarEstudianteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnBuscarEstudianteKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.buscar();
    }//GEN-LAST:event_btnBuscarEstudianteKeyPressed

    private void btnBuscarEstudianteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarEstudianteActionPerformed
        this.buscar();
    }//GEN-LAST:event_btnBuscarEstudianteActionPerformed

    private void btnEliminarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnEliminarKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.eliminar();
    }//GEN-LAST:event_btnEliminarKeyPressed

    private void txtNumControlKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumControlKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            this.buscar();
    }//GEN-LAST:event_txtNumControlKeyPressed

    private void txtNumControlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumControlActionPerformed


    }//GEN-LAST:event_txtNumControlActionPerformed

    /**
     * Busca un estudiante en base al número de control. Si existe, carga sus
     * datos en los campos.
     */
    private void buscar() {
        String numControl = this.txtNumControl.getText().trim();

        if (!objControladorCRUDEst.validaNumControl(numControl)) {
            JOptionPane.showMessageDialog(this, "Número de control inválido. Debe tener 8 caracteres.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String registro[] = this.objControladorCRUDEst.buscarRegistro(numControl);

        if (registro != null) {
            this.txtNombre.setText(registro[1]);
            this.txtApellidos.setText(registro[2]);

            try {
                int semestre = Integer.parseInt(registro[3].trim());
                this.cboSemestre.setSelectedItem(String.valueOf(semestre));
            } catch (NumberFormatException e) {
                System.err.println("Error al convertir semestre: " + registro[3]);
            }

            char grupo = registro[4].charAt(0);
            switch (grupo) {
                case 'A':
                    this.rdbtnGrupoA.setSelected(true);
                    break;
                case 'B':
                    this.rdbtnGrupoB.setSelected(true);
                    break;
                case 'C':
                    this.rdbtnGrupoC.setSelected(true);
                    break;
            }

            this.cboCarrera.setSelectedItem(registro[5]);
            this.btnEliminar.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(this, "El registro no existe", "Búsqueda", JOptionPane.WARNING_MESSAGE);
            limpiarFormulario();
        }
    }

    /**
     * Elimina el registro del estudiante actualmente cargado, tras confirmar la
     * acción.
     */
    private void eliminar() {
        if (this.txtNombre.getText().isEmpty() || this.txtApellidos.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Primero debes buscar un estudiante antes de eliminarlo.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int respuesta = JOptionPane.showConfirmDialog(this, "¿Estás seguro de eliminar el registro?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (respuesta == JOptionPane.YES_OPTION) {
            String numControl = this.txtNumControl.getText();
            boolean eliminado = this.objControladorCRUDEst.eliminarRegistro(numControl);

            if (eliminado) {
                JOptionPane.showMessageDialog(this, "Registro eliminado exitosamente.");
                limpiarFormulario();
                this.deshabilitaComponentes(false);
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo eliminar el registro. Intenta nuevamente.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Limpia el formulario y reinicia los campos a su estado inicial.
     */
    private void limpiarFormulario() {
        this.txtNumControl.setText("");
        this.txtNombre.setText("");
        this.txtApellidos.setText("");
        this.cboSemestre.setSelectedIndex(0);
        this.rdbtnGrupoA.setSelected(true);
        this.cboCarrera.setSelectedIndex(0);
        this.btnEliminar.setEnabled(false);
        this.txtNumControl.requestFocus();
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscarEstudiante;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JComboBox<String> cboCarrera;
    private javax.swing.JComboBox<String> cboSemestre;
    private javax.swing.ButtonGroup gpoBotonesGrupo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton rdbtnGrupoA;
    private javax.swing.JRadioButton rdbtnGrupoB;
    private javax.swing.JRadioButton rdbtnGrupoC;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNumControl;
    // End of variables declaration//GEN-END:variables
}
