package modelo;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase que se encarga de gestionar el almacenamiento y recuperación de
 * registros de estudiantes usando organización directa en un archivo binario
 * con una longitud fija.
 *
 * Cada estudiante se guarda en una posición determinada por su número de
 * control, lo cual permite un acceso directo sin necesidad de recorrer todo el
 * archivo.
 */
public class ArchivoOrganizacionDirecta {

    public static final String ARCHIVO_DAT = "estudiantes.dat"; // archivo binario
    private RandomAccessFile raf;

    private final int NUMCONTROL_LEN = 8;
    private final int NOMBRE_LEN = 20;
    private final int APELLIDOS_LEN = 20;
    private final int SEMESTRE_LEN = 2;
    private final int GRUPO_LEN = 1;
    private final int CARRERA_LEN = 30;
    private final int TAMANOREGISTRO = NUMCONTROL_LEN + NOMBRE_LEN + APELLIDOS_LEN + SEMESTRE_LEN + GRUPO_LEN + CARRERA_LEN;

    /**
     * Abre el archivo binario para lectura y escritura. Si no existe, lo crea.
     *
     * @return true si el archivo fue abierto correctamente; false si ocurrió un
     * error.
     */
    public boolean abrirArchivoRAF() {
        try {
            this.raf = new RandomAccessFile(ARCHIVO_DAT, "rw");
            return true;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ArchivoOrganizacionDirecta.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    /**
     * Cierra el archivo binario si está abierto.
     */
    public void cerrarArchivo() {
        try {
            if (raf != null) {
                raf.close();
            }
        } catch (IOException ex) {
            Logger.getLogger(ArchivoOrganizacionDirecta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Ajusta una cadena a una longitud fija, rellenando con espacios si es
     * necesario, o recortando si excede.
     *
     * @param s cadena original
     * @param longitud longitud deseada
     * @return cadena ajustada a la longitud especificada
     */
    private static String ajustar(String s, int longitud) {
        return String.format("%-" + longitud + "s", s).substring(0, longitud);
    }

    /**
     * Calcula la posicion en bytes donde se debe almacenar o leer un registro,
     * en base a los últimos 3 dígitos del número de control.
     *
     * @param numeroControl numero de control del estudiante
     * @return posicion en bytes en el archivo
     */
    private long establecerPosicionByte(String numeroControl) {
        return ((Long.parseLong(numeroControl.substring(5))) - 1) * TAMANOREGISTRO;
    }

    /**
     * Valida que un número de control tenga exactamente 8 dígitos numéricos.
     *
     * @param numControl número de control a validar
     * @return true si es válido; false en caso contrario
     */
    public boolean validaControl(String numControl) {
        return numControl.matches("^[0-9]{8}$");
    }

    /**
     * Verifica si un número de control ya existe en el archivo.
     *
     * @param numeroControl número de control a verificar
     * @return true si existe; false si no
     */
    public boolean existeNC(String numeroControl) {
        try {
            // Calcula la posición exacta en el archivo basada en el número de control
            long posicion = establecerPosicionByte(numeroControl);

            // Posiciona el puntero del archivo en esa ubicación
            raf.seek(posicion);

            // Crea un buffer para leer exactamente los caracteres del número de control
            byte[] registroBytes = new byte[NUMCONTROL_LEN];
            raf.readFully(registroBytes); // Lee los bytes desde el archivo

            // Convierte los bytes leídos a cadena usando la codificación original y elimina espacios extra
            String nControl = new String(registroBytes, "ISO-8859-1").trim();

            return nControl.equals(numeroControl);

        } catch (IOException ex) {
            // Si ocurre un error, se asume que el número no existe
            return false;
        }
    }

    /**
     * Escribe un nuevo registro de estudiante en la posición correspondiente
     * según su número de control.
     *
     * @param numControl número de control del estudiante (8 dígitos)
     * @param nombre nombre del estudiante
     * @param apellidos apellidos del estudiante
     * @param semestre semestre actual del estudiante (1 a 12)
     * @param grupo grupo al que pertenece el estudiante (una letra)
     * @param carrera carrera que cursa el estudiante
     */
    public void escribirRegistro(String numControl, String nombre, String apellidos, int semestre, char grupo, String carrera) {
        try {
            long posicionByte = establecerPosicionByte(numControl);
            raf.seek(posicionByte); // Mover el puntero del archivo a esa posición

            raf.write(ajustar(numControl, NUMCONTROL_LEN).getBytes("ISO-8859-1"));
            raf.write(ajustar(nombre, NOMBRE_LEN).getBytes("ISO-8859-1"));
            raf.write(ajustar(apellidos, APELLIDOS_LEN).getBytes("ISO-8859-1"));
            raf.write(new DecimalFormat("00").format(semestre).getBytes("ISO-8859-1"));
            raf.write(String.valueOf(grupo).getBytes("ISO-8859-1"));
            raf.write(ajustar(carrera, CARRERA_LEN).getBytes("ISO-8859-1"));

        } catch (IOException e) {
            Logger.getLogger(ArchivoOrganizacionDirecta.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    /**
     * Busca un registro de estudiante por su número de control y devuelve sus
     * datos.
     *
     * @param nc número de control del estudiante
     * @return un arreglo con los campos del estudiante, o null si está vacío
     */
    public String[] buscarRegistro(String nc) {
        String[] datos = new String[6]; // arreglo para almacenar los campos del estudiante
        try {
            long pos = establecerPosicionByte(nc);
            raf.seek(pos);
            byte[] registroBytes = new byte[TAMANOREGISTRO];
            raf.readFully(registroBytes);

            int posicionActual = 0;

            datos[0] = new String(registroBytes, posicionActual, NUMCONTROL_LEN, "ISO-8859-1").trim();
            if (datos[0].isBlank()) {
                return null; // si el número de control está vacío, se considera que no hay registro
            }

            posicionActual += NUMCONTROL_LEN;
            datos[1] = new String(registroBytes, posicionActual, NOMBRE_LEN, "ISO-8859-1").trim();

            posicionActual += NOMBRE_LEN;
            datos[2] = new String(registroBytes, posicionActual, APELLIDOS_LEN, "ISO-8859-1").trim();

            posicionActual += APELLIDOS_LEN;
            datos[3] = new String(registroBytes, posicionActual, SEMESTRE_LEN, "ISO-8859-1").trim();

            posicionActual += SEMESTRE_LEN;
            datos[4] = new String(registroBytes, posicionActual, GRUPO_LEN, "ISO-8859-1").trim();

            posicionActual += GRUPO_LEN;
            datos[5] = new String(registroBytes, posicionActual, CARRERA_LEN, "ISO-8859-1").trim();

        } catch (IOException ex) {
            Logger.getLogger(ArchivoOrganizacionDirecta.class.getName()).log(Level.SEVERE, null, ex);
        }

        return datos; // devuelve el arreglo con los datos del estudiante
    }

    /**
     * Calcula el número total de registros almacenados en el archivo, basándose
     * en el tamaño fijo de cada registro.
     *
     * @return el total de registros que caben en el archivo; devuelve 0 si
     * ocurre un error al obtener el tamaño del archivo
     */
    public int getTotalRegistros() {
        try {
            return (int) (raf.length() / TAMANOREGISTRO);
        } catch (IOException e) {
            Logger.getLogger(ArchivoOrganizacionDirecta.class.getName()).log(Level.SEVERE, null, e);
            return 0;
        }
    }

    /**
     * Obtiene todos los registros válidos (no vacíos) en el orden en que están
     * en el archivo.
     *
     * @return matriz con los datos de todos los estudiantes
     */
    public String[][] obtenerTodosLosRegistros() {
        try {
            int total = getTotalRegistros();
            // Para almacenar la cantidad máxima posible de registros válidos
            List<String[]> listaRegistros = new ArrayList<>();

            for (int x = 0; x < total; x++) {
                raf.seek(x * TAMANOREGISTRO);
                byte[] registroBytes = new byte[TAMANOREGISTRO];
                raf.readFully(registroBytes);

                String numControl = new String(registroBytes, 0, NUMCONTROL_LEN, "ISO-8859-1").trim();
                if (numControl.isBlank()) {
                    continue; // Ignorar registros vacíos
                }

                String[] datos = new String[6];
                datos[0] = numControl;
                datos[1] = new String(registroBytes, NUMCONTROL_LEN, NOMBRE_LEN, "ISO-8859-1").trim();
                datos[2] = new String(registroBytes, NUMCONTROL_LEN + NOMBRE_LEN, APELLIDOS_LEN, "ISO-8859-1").trim();
                datos[3] = new String(registroBytes, NUMCONTROL_LEN + NOMBRE_LEN + APELLIDOS_LEN, SEMESTRE_LEN, "ISO-8859-1").trim();
                datos[4] = new String(registroBytes, NUMCONTROL_LEN + NOMBRE_LEN + APELLIDOS_LEN + SEMESTRE_LEN, GRUPO_LEN, "ISO-8859-1").trim();
                datos[5] = new String(registroBytes, NUMCONTROL_LEN + NOMBRE_LEN + APELLIDOS_LEN + SEMESTRE_LEN + GRUPO_LEN, CARRERA_LEN, "ISO-8859-1").trim();

                listaRegistros.add(datos);
            }

            // Convertir la lista a matriz y devolver
            String[][] resultado = new String[listaRegistros.size()][6];
            for (int i = 0; i < listaRegistros.size(); i++) {
                resultado[i] = listaRegistros.get(i);
            }
            return resultado;
        } catch (IOException ex) {
            Logger.getLogger(ArchivoOrganizacionDirecta.class.getName()).log(Level.SEVERE, null, ex);
            return new String[0][0];
        }
    }

    /**
     * Elimina un estudiante del archivo rellenando su espacio con ceros.
     *
     * @param numControl número de control del estudiante a eliminar
     * @return true si se eliminó; false si no se encontró
     */
    public boolean eliminarEstudiante(String numControl) {
        try {
            long posicionByte = establecerPosicionByte(numControl);
            raf.seek(posicionByte);

            byte[] registroBytes = new byte[TAMANOREGISTRO];
            raf.readFully(registroBytes);

            // Verificar si el registro está vacío (ya eliminado)
            String ncLeido = new String(registroBytes, 0, NUMCONTROL_LEN, "ISO-8859-1").trim();
            if (ncLeido.isBlank()) {
                return false; // No existe registro con ese número de control
            }

            // Sobrescribir el registro completo con ceros para "eliminarlo"
            raf.seek(posicionByte);
            raf.write(new byte[TAMANOREGISTRO]);

            return true;
        } catch (IOException e) {
            Logger.getLogger(ArchivoOrganizacionDirecta.class.getName()).log(Level.SEVERE, null, e);
            return false;
        }
    }

    /**
     * Modifica los datos de un estudiante existente en su misma posición.
     *
     * @param numControl número de control del estudiante
     * @param nombre nuevo nombre
     * @param apellidos nuevos apellidos
     * @param semestre nuevo semestre
     * @param grupo nuevo grupo
     * @param carrera nueva carrera
     * @return true si se modificó; false si no se encontró
     */
    public boolean modificarRegistro(String numControl, String nombre, String apellidos, int semestre, char grupo, String carrera) {
        try {
            long posicion = establecerPosicionByte(numControl);
            raf.seek(posicion);

            // Leer el número de control para validar que el registro existe
            byte[] registroBytes = new byte[NUMCONTROL_LEN];
            raf.readFully(registroBytes);
            String nc = new String(registroBytes, "ISO-8859-1").trim();

            if (nc.isBlank() || !nc.equals(numControl)) {
                // Registro no existe o está vacío
                return false;
            }

            // Volver a posicionar para escribir el registro actualizado
            raf.seek(posicion);
            escribirRegistro(numControl, nombre, apellidos, semestre, grupo, carrera);

            return true;
        } catch (IOException ex) {
            Logger.getLogger(ArchivoOrganizacionDirecta.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}