package controlador;

import javax.swing.table.DefaultTableModel;
import modelo.ArchivoOrganizacionDirecta;
import vista.VistaCRUDEstudiantes;

/**
 * Controlador que gestiona la comunicación entre la vista y el modelo para las
 * operaciones CRUD sobre los estudiantes.
 */
public class ControladorCRUDEstudiantes {

    private final VistaCRUDEstudiantes vista;
    private final ArchivoOrganizacionDirecta archivo;

    /**
     * Constructor del controlador.
     *
     * @param vista la vista asociada a este controlador.
     * @param archivo el modelo que maneja la lógica de acceso al archivo.
     */
    public ControladorCRUDEstudiantes(VistaCRUDEstudiantes vista, ArchivoOrganizacionDirecta archivo) {
        this.vista = vista;
        this.archivo = archivo;
    }

    /**
     * Guarda un nuevo registro si el número de control no existe.
     *
     * @param nc número de control del estudiante.
     * @param nom nombre del estudiante.
     * @param ape apellidos del estudiante.
     * @param sem semestre.
     * @param gpo grupo.
     * @param carrera carrera.
     * @return true si se guardó correctamente, false si el número de control ya
     * existe.
     */
    public boolean guardarRegistro(String nc, String nom, String ape, int sem, char gpo, String carrera) {
        archivo.abrirArchivoRAF();
        if (archivo.existeNC(nc)) {
            archivo.cerrarArchivo();
            return false;
        }
        archivo.escribirRegistro(nc, nom, ape, sem, gpo, carrera);
        archivo.cerrarArchivo();
        return true;
    }

    /**
     * Busca un estudiante por número de control.
     *
     * @param nc número de control del estudiante.
     * @return un arreglo con los datos del estudiante o null si no se encontró.
     */
    public String[] buscarRegistro(String nc) {
        archivo.abrirArchivoRAF();
        String[] datos = archivo.buscarRegistro(nc);
        archivo.cerrarArchivo();
        return datos;
    }

    /**
     * Llena la tabla de la vista con todos los registros ordenados por número
     * de control.
     */
    public void llenarTabla() {
        archivo.abrirArchivoRAF();
        String[][] filas = archivo.obtenerTodosLosRegistros();
        archivo.cerrarArchivo();

        String[] columnas = {"Num. Control", "Nombre", "Apellidos", "Semestre", "Grupo", "Carrera"};
        vista.jtblEstudiantes.setModel(new DefaultTableModel(filas, columnas));
    }

    /**
     * Elimina un estudiante por su número de control.
     *
     * @param nc número de control del estudiante.
     * @return true si se eliminó correctamente, false si no se encontró.
     */
    public boolean eliminarRegistro(String nc) {
        archivo.abrirArchivoRAF();
        boolean eliminado = archivo.eliminarEstudiante(nc);
        archivo.cerrarArchivo();
        if (eliminado) {
            llenarTabla();
        }
        return eliminado;
    }

    /**
     * Modifica un registro existente.
     *
     * @param nc número de control.
     * @param nom nuevo nombre.
     * @param ape nuevos apellidos.
     * @param sem nuevo semestre.
     * @param gpo nuevo grupo.
     * @param carrera nueva carrera.
     * @return true si se modificó correctamente, false si no se encontró el
     * registro.
     */
    public boolean modificarRegistro(String nc, String nom, String ape, int sem, char gpo, String carrera) {
        archivo.abrirArchivoRAF();
        boolean modificado = archivo.modificarRegistro(nc, nom, ape, sem, gpo, carrera);
        archivo.cerrarArchivo();
        if (modificado) {
            llenarTabla();
        }
        return modificado;
    }

    /**
     * Valida que el número de control tenga el formato correcto (8 dígitos).
     *
     * @param nc número de control.
     * @return true si el formato es válido, false si no lo es.
     */
    public boolean validaNumControl(String nc) {
        return archivo.validaControl(nc);
    }
}
